﻿using StudentManagement.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace StudentManagement.DAL
{
    public class SchoolInitializer : DropCreateDatabaseIfModelChanges<SchoolContext>
    {
        protected override void Seed(SchoolContext context)
        {
            var students = new List<Student>
            {
                new Student { LastName="Tran Van", FristName="Thanh", Address="100 Hung Vuong", Phone="0123456789", DOB=DateTime.Parse("1995-02-13"), EnrollmentDate=DateTime.Parse("2005-09-11") },
                new Student { LastName="Dao Dai", FristName="Vu", Address="100 Le Duan", Phone="0123456789", DOB=DateTime.Parse("1994-07-10"), EnrollmentDate=DateTime.Parse("2007-12-03") },
                new Student { LastName="Tran Kiet", FristName="Luan", Address="94 Nguyen Chi Thanh", Phone="0123456789", DOB=DateTime.Parse("1988-02-14"), EnrollmentDate=DateTime.Parse("2010-04-11") },
                new Student { LastName="Ton That", FristName="Giau", Address="77 Le Do", Phone="0123456789", DOB=DateTime.Parse("1999-08-15"), EnrollmentDate=DateTime.Parse("2012-03-28") },
                new Student { LastName="Do Phuoc", FristName="Hung", Address="111 Le Lai", Phone="0123456789", DOB=DateTime.Parse("1990-05-15"), EnrollmentDate=DateTime.Parse("2014-05-28") }
            };
            students.ForEach(s => context.Students.Add(s));
            context.SaveChanges();

            var courses = new List<Course>
            {
                new Course{Title="Chemistry",Credits=3,},
                new Course{Title="Microeconomics",Credits=3,},
                new Course{Title="Macroeconomics",Credits=3,},
                new Course{Title="Calculus",Credits=4,},
                new Course{Title="Trigonometry",Credits=4,},
                new Course{Title="Composition",Credits=3,},
                new Course{Title="Literature",Credits=4,}
            };
            courses.ForEach(s => context.Courses.Add(s));
            context.SaveChanges();

            var enrollments = new List<Enrollment>
            {
                 new Enrollment{StudentID=1,CourseID=1,Grade=1},
                 new Enrollment{StudentID=1,CourseID=4,Grade=2},
                 new Enrollment{StudentID=1,CourseID=2,Grade=3},
                 new Enrollment{StudentID=2,CourseID=1,Grade=2},
                 new Enrollment{StudentID=2,CourseID=3,Grade=3},
                 new Enrollment{StudentID=2,CourseID=5,Grade=2},
                 new Enrollment{StudentID=3,CourseID=6},
                 new Enrollment{StudentID=4,CourseID=2},
                 new Enrollment{StudentID=4,CourseID=3,Grade=1},
                 new Enrollment{StudentID=5,CourseID=5,Grade=3},
                 new Enrollment{StudentID=5,CourseID=6},
                 new Enrollment{StudentID=5,CourseID=1,Grade=4}
            };
            enrollments.ForEach(s => context.Enrollments.Add(s));
            context.SaveChanges();

        }
    }
}