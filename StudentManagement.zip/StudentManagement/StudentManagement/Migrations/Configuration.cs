namespace StudentManagement.Migrations
{
    using Models;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<StudentManagement.DAL.SchoolContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(StudentManagement.DAL.SchoolContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data. E.g.
            //
            //    context.People.AddOrUpdate(
            //      p => p.FullName,
            //      new Person { FullName = "Andrew Peters" },
            //      new Person { FullName = "Brice Lambson" },
            //      new Person { FullName = "Rowan Miller" }
            //    );
            //

            var students = new List<Student>
            {
                new Student { LastName="Tran Van", FristName="Thanh", Address="100 Hung Vuong", Phone="0123456789", DOB=DateTime.Parse("1995-02-13"), EnrollmentDate=DateTime.Parse("2005-09-11") },
                new Student { LastName="Dao Dai", FristName="Vu", Address="100 Le Duan", Phone="0123456789", DOB=DateTime.Parse("1994-07-10"), EnrollmentDate=DateTime.Parse("2007-12-03") },
                new Student { LastName="Tran Kiet", FristName="Luan", Address="94 Nguyen Chi Thanh", Phone="0123456789", DOB=DateTime.Parse("1988-02-14"), EnrollmentDate=DateTime.Parse("2010-04-11") },
                new Student { LastName="Ton That", FristName="Giau", Address="77 Le Do", Phone="0123456789", DOB=DateTime.Parse("1999-08-15"), EnrollmentDate=DateTime.Parse("2012-03-28") },
                new Student { LastName="Do Phuoc", FristName="Hung", Address="111 Le Lai", Phone="0123456789", DOB=DateTime.Parse("1990-05-15"), EnrollmentDate=DateTime.Parse("2014-05-28") }
            };
            students.ForEach(s => context.Students.AddOrUpdate(p => p.LastName, s));
            context.SaveChanges();

            var courses = new List<Course>
            {
                new Course{Title="Chemistry",Credits=3,},
                new Course{Title="Microeconomics",Credits=3,},
                new Course{Title="Macroeconomics",Credits=3,},
                new Course{Title="Calculus",Credits=4,},
                new Course{Title="Trigonometry",Credits=4,},
                new Course{Title="Composition",Credits=3,},
                new Course{Title="Literature",Credits=4,}
            };
            courses.ForEach(s => context.Courses.AddOrUpdate(p => p.Title, s));
            context.SaveChanges();

            var enrollments = new List<Enrollment>
            {
                new Enrollment {StudentID = students.Single(s => s.LastName =="Tran Van").ID, CourseID = courses.Single(c => c.Title == "Chemistry" ).CourseID, Grade = 1},
                new Enrollment {StudentID = students.Single(s => s.LastName =="Tran Van").ID, CourseID = courses.Single(c => c.Title == "Calculus" ).CourseID, Grade = 2},
                new Enrollment {StudentID = students.Single(s => s.LastName =="Tran Van").ID, CourseID = courses.Single(c => c.Title == "Microeconomics" ).CourseID, Grade = 1},
                new Enrollment {StudentID = students.Single(s => s.LastName =="Dao Dai").ID, CourseID = courses.Single(c => c.Title == "Chemistry" ).CourseID, Grade = 3},
                new Enrollment {StudentID = students.Single(s => s.LastName =="Dao Dai").ID, CourseID = courses.Single(c => c.Title == "Macroeconomics" ).CourseID, Grade = 2},
                new Enrollment {StudentID = students.Single(s => s.LastName =="Dao Dai").ID, CourseID = courses.Single(c => c.Title == "Trigonometry" ).CourseID, Grade = 3},
                new Enrollment {StudentID = students.Single(s => s.LastName =="Tran Kiet").ID, CourseID = courses.Single(c => c.Title == "Composition" ).CourseID, Grade = 4},
                new Enrollment {StudentID = students.Single(s => s.LastName =="Tran Kiet").ID, CourseID = courses.Single(c => c.Title == "Macroeconomics" ).CourseID, Grade = 2}

            };
            foreach (Enrollment e in enrollments)
            {
                var enrollmentInDatabase = context.Enrollments.Where(s => s.Student.ID == e.StudentID && s.Course.CourseID == e.CourseID).SingleOrDefault();
                if (enrollmentInDatabase == null)
                {
                    context.Enrollments.Add(e);
                }
                context.SaveChanges();
            }
            
        }
    }
}
