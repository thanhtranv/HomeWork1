﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace StudentManagement.Models
{
    public class Student
    {
        public int ID { get; set; }
        public string LastName { get; set; }
        public string FristName { get; set; }
        public string Address { get; set; }

        public string Phone { get; set; }
        public DateTime DOB { get; set; }
        public DateTime EnrollmentDate { get; set; }

        public virtual ICollection<Enrollment> Enrollments { get; set; }
    }
}